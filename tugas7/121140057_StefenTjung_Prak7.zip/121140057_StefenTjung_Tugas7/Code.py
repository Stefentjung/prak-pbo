import tkinter as tk
from tkinter import messagebox

# Create the main window
window = tk.Tk()
window.title("Tic Tac Toe")

# Create a list to store the buttons
buttons = []

# Variables to track the current player and number of moves
current_player = "X"
moves = 0

# Load the X and O images with subsampling
x_image = tk.PhotoImage("Assets/x_image.png")
o_image = tk.PhotoImage("Assets/o_image.png")

# Function to handle button click
def button_click(index):
    global current_player, moves
    button = buttons[index]
    
    # Check if the button has already been clicked
    if button["text"] == "":
        button["text"] = current_player
        button["image"] = x_image if current_player == "X" else o_image
        moves += 1
        
        # Check for a winner
        if check_winner(current_player):
            messagebox.showinfo("Winner", f"Player {current_player} wins!")
            reset_game()
        elif moves == 9:
            messagebox.showinfo("Draw", "The game is a draw!")
            reset_game()
        else:
            # Switch to the other player
            current_player = "O" if current_player == "X" else "X"

# Function to check for a winner
def check_winner(player):
    # Check rows
    for i in range(0, 7, 3):
        if buttons[i]["text"] == buttons[i + 1]["text"] == buttons[i + 2]["text"] == player:
            return True
    
    # Check columns
    for i in range(3):
        if buttons[i]["text"] == buttons[i + 3]["text"] == buttons[i + 6]["text"] == player:
            return True
    
    # Check diagonals
    if buttons[0]["text"] == buttons[4]["text"] == buttons[8]["text"] == player:
        return True
    if buttons[2]["text"] == buttons[4]["text"] == buttons[6]["text"] == player:
        return True
    
    return False

# Function to reset the game
def reset_game():
    global current_player, moves
    current_player = "X"
    moves = 0
    for button in buttons:
        button["text"] = ""
        button["image"] = ""

# Create and place the buttons
for i in range(9):
    button = tk.Button(window, text="", image=None, width=10, height=4, compound=tk.CENTER,
                       command=lambda index=i: button_click(index))
    button.grid(row=i // 3, column=i % 3)
    buttons.append(button)

# Start the main loop
window.mainloop()
